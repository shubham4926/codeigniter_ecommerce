<?php
/* Custom functions code goes here. */
//* Add CSS directly into the admin head
add_action( 'admin_head', 'rv_custom_wp_admin_style_head' );
function rv_custom_wp_admin_style_head() { ?>
<style>
    .us-screenlock{display:none !important;}; 
    .error us-migration for-hb{display:none !important;};
</style>
<?php }
 