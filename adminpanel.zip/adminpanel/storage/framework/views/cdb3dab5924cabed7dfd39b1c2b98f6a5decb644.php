<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Pooled Admin Panel Category Flat Bootstrap Responsive Web Template | Input :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="public/assets/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="public/assets/css/style.css" rel='stylesheet' type='text/css' />
<link href="public/assets/css/custom.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="public/assets/css/morris.css" type="text/css"/>
<!-- Graph CSS -->
<link href="public/assets/css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<script src="public/assets/js/jquery-2.1.4.min.js"></script>
<!-- //jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="public/assets/css/icon-font.min.css" type='text/css' />
<!-- //lined-icons -->
</head> 
<body>
   <div class="page-container">
   <!--/content-inner-->
<div class="left-content">
	   <div class="mother-grid-inner">
                   <!--header start here-->
				 <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="container">
	<h2>Add New Blog Post</h2>
  <!-- Button to Open the Modal -->
  <button type="button" class="btn btn-primary add_new_blog" data-toggle="modal" data-target="#myModal">
    Click to Add Blog Post
  </button>
  <!-- The Modal -->
  <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Add New Blog Post</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div
        <!-- Modal body -->
        <div class="modal-body">
		<form>
			<div class="form-group">
			<label for="exampleInputEmail1">Add Post</label>
			<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Add Post Title">
			</div>
			<textarea class="tinymce"></textarea>
			<input type="submit" class="btn btn-primary submit_blog_post">
		</form>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block">

</div>
<!--inner block end here-->
<!--copy rights start here-->
<div class="copyrights">
	 <p>� 2016 Pooled . All Rights Reserved | Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
</div>	
<!--COPY rights end here-->
</div>
</div>
 <?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
<script src="public/assets/js/jquery.nicescroll.js"></script>
<script src="public/assets/js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="public/assets/js/bootstrap.min.js"></script>
 <script type="text/javascript" src="public/tinymce/plugin/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="public/tinymce/plugin/tinymce/init-tinymce.js"></script>
   <!-- /Bootstrap Core JavaScript -->	   

</body>
</html>