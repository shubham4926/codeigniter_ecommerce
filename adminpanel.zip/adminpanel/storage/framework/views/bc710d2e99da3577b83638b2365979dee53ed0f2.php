 
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Pooled Admin Panel Category Flat Bootstrap Responsive Web Template | Sign In :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="../../public/assets/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="../../public/assets/css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="../../public/assets/css/morris.css" type="text/css"/>
<!-- Graph CSS -->
<link href="../../public/assets/css/font-awesome.css" rel="stylesheet">
<link rel="stylesheet" href="../../public/assets/css/jquery-ui.css"> 
<!-- jQuery -->
<script src="../../public/assets/js/jquery-2.1.4.min.js"></script>
<!-- //jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="../../public/assets/css/icon-font.min.css" type='text/css' />
<!-- //lined-icons -->
</head> 
<body>
	<div class="main-wthree">
	<div class="container">
	<div class="sin-w3-agile">
		<h2><?php echo e(__('Reset Password')); ?></h2>
			<form method="POST" action="<?php echo e(route('password.request')); ?>" aria-label="<?php echo e(__('Reset Password')); ?>">
                        <?php echo csrf_field(); ?>

          <input type="hidden" name="token" value="<?php echo e($token); ?>">
			<div class="username">
				 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
				<span class="username"><?php echo e(__('E-Mail Address')); ?></span>
				<input id="email" type="email" class="name<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($email ?? old('email')); ?>" required autofocus>
				  <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
				<div class="clearfix"></div>
			</div>
			  
			  <div class="password-agileits">
				<span class="username"><?php echo e(__('Password')); ?></span>
				 <input id="password" type="password" class="password<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
				 <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
				<div class="clearfix"></div>
			</div>
			<div class="password-agileits">
				<span class="username"><?php echo e(__('Confirm Password')); ?></span>
				<input id="password-confirm" type="password" class="password" name="password_confirmation" required>
				<div class="clearfix"></div>
			</div>
			<div class="login-w3">
					<input type="submit" class="login" value="  <?php echo e(__('Reset Password')); ?>" style="width:100%">
			</div>
			<div class="clearfix"></div>
		</form>
				<div class="footer">
				 
				</div>
	</div>
	</div>
	</div>
</body>
</html>