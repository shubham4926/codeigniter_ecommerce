<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('signin');
});
Route::get('/signin', function () {
    return view('signin');
});
Route::get('/emailreset', function () {
    return view('emailreset');
});
Route::get('/passwordreset/{token}', function () {
    return view('passwordreset');
});
Route::get('/dashboard', function () {
    return view('dashboard');
});
Route::get('/signup', function () {
    return view('signup');
});
Route::get('/blog', function () {
    return view('blog');
});
Route::get('/validation', function () {
    return view('validation');
});
Route::get('/typography', function () {
    return view('typography');
});
Route::get('/tables', function () {
    return view('tables');
});
Route::get('/maps', function () {
    return view('maps');
});
Route::get('/input', function () {
    return view('input');
});
Route::get('/inbox', function () {
    return view('inbox');
});
Route::get('/icons', function () {
    return view('icons');
});
Route::get('/grid', function () {
    return view('grid');
});
Route::get('/gallery', function () {
    return view('gallery');
});
Route::get('/faq', function () {
    return view('faq');
});
Route::get('/errorpage', function () {
    return view('errorpage');
});
Route::get('/edit_blog', function () {
    return view('edit_blog');
});
Route::get('/charts', function () {
    return view('charts');
});
Route::get('/calendar', function () {
    return view('calendar');
});
Route::get('/stripe', function () {
    return view('stripe');
});
Route::get('/button', function () {
    return view('button');
});
Route::post('payment', 'AddBlog@pay');
Route::post('update_blog/{id}','AddBlog@blog_update');
Route::get('delete/{id}','AddBlog@delete_blog');
Route::get('edit/{id}','AddBlog@edit_blog');
Route::post('/userdetails', 'Register@userdetails');
Route::post('/addblog', 'AddBlog@addblog_post');
Route::get('blog','AddBlog@show_post');
Auth::routes();
Route::post('/index_login','Auth\LoginController@log_in');
Route::get('/index_logout','Auth\LoginController@log_out');
Route::get('/home', 'HomeController@index')->name('home');
