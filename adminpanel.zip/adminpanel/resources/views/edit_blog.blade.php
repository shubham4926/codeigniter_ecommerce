<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Pooled Admin Panel Category Flat Bootstrap Responsive Web Template | Input :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="{{ asset('public/assets/css/bootstrap.min.css') }}" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->


<link rel="stylesheet" type="text/css" href="{{ asset('public/assets/css/style.css') }}">
<link rel="stylesheet" href="{{ asset('public/assets/css/morris.css') }}" type="text/css"/>
<!-- Graph CSS -->
<link href="{{ asset('public/assets/css/font-awesome.css') }}" rel="stylesheet">
<!-- jQuery -->
<script src="{{ asset('public/assets/js/jquery-2.1.4.min.js') }}"></script>
<!-- //jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="{{ asset('public/assets/css/icon-font.min.css') }}" type='text/css' />
<!-- //lined-icons -->
</head>
<body>
   <div class="page-container">
   <!--/content-inner-->
<div class="left-content">
	   <div class="mother-grid-inner">
                   <!--header start here-->
				 @include('header')
<!--heder end here-->
 	<div class="grid-form">
 		<div class="grid-form1">
 		<h2 id="forms-example" class="">Edit Blog</h2>
 		<form  action="{{url('update_blog')}}/<?php echo $edit_records[0]->b_id; ?>" method="post">
            <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
  <div class="form-group">
    <label for="exampleInputEmail1">Blog Title</label>
    <input type="text" class="form-control"  value="<?php echo $edit_records[0]->blog_title; ?>" name="e_blog">
  </div>
  <div class="form-group">
    <label for="txtarea1" class="control-label">Blog Description</label>
    <textarea name="e_description" class="tinymce" cols="50" rows="10" class="form-control1"><?php echo $edit_records[0]->blog_description; ?></textarea>
  </div>
  <input type="submit" name="edit_submit"class="btn btn-primary submit_blog_post">
</form>
</div>
  </div>
 	</div>
 	<!--//grid-->

<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop();
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });

		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block">

</div>
<!--inner block end here-->
<!--copy rights start here-->
<div class="copyrights">
	 <p>© 2016 Pooled . All Rights Reserved | Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
</div>
<!--COPY rights end here-->
</div>
</div>
 @include('sidebar');
<script src="{{ asset('public/assets/js/jquery.nicescroll.js') }}"></script>
<script src="{{ asset('public/assets/js/scripts.js') }}"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="{{ asset('public/assets/js/bootstrap.min.js') }}"></script>
   <script type="text/javascript" src="{{ asset('public/tinymce/plugin/tinymce/tinymce.min.js') }}"></script>
  <script type="text/javascript" src="{{ asset('public/tinymce/plugin/tinymce/init-tinymce.js') }}"></script>
   <!-- /Bootstrap Core JavaScript -->

</body>
</html>
