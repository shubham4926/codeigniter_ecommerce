<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Support\Facades\Hash;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Register extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
	public function userdetails(Request $req)
    {
		$name=$req->input('name');
		$email=$req->input('email');
		$password=$req->input('password');
		$hashedPassword = Hash::make($password);
		$data=array('name'=>$name,'email'=>$email,'password'=>$hashedPassword);
		DB::table('users')->insert($data);
		return back()->with('success','Thank You , Now you are registered!');
    }
}
