<?php

namespace App\Http\Controllers;
use Auth;
use Illuminate\Http\Request;
use DB;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Support\Facades\Hash;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class AddBlog extends BaseController
{
use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
public function addblog_post(Request $req)
{
  $user = Auth::user();
  $current_user= $user['id'];
  echo $post_title=$req->input('post_title');
  echo $post_desc=$req->input('post_desc');
  $data=array('user_id'=> $current_user,'blog_title'=>$post_title,'blog_description'=>$post_desc);
  DB::table('blog')->insert($data);
  return back()->with('success','Blog is Published');
}
public function show_post() {
  $user = Auth::user();
  $current_user= $user['id'];
   $blog_data = DB::select('select * from blog where user_id = :current_users', ['current_users' => $current_user]);
   return view('blog',['blog'=>$blog_data]);
}
public function delete_blog($id) {
  DB::delete('delete from blog where b_id = ?',[$id]);
  return back()->with('Deleted','Selected Blog Is deleted');
}
public function edit_blog($id) {
  $edit_records = DB::select('select * from blog where b_id = ?',[$id]);
        return view('edit_blog',['edit_records'=>$edit_records]);
}
public function blog_update(Request $request,$id) {
  $e_blog = $request->input('e_blog');
  $e_description = $request->input('e_description');
  DB::update('update blog set blog_title = ?,blog_description = ? where b_id = ?',[$e_blog,$e_description,$id]);
    return redirect('/blog')->with('edit_blog', 'Data Is Edited');
}
public function pay(Request $request)
   {
     \Stripe\Stripe::setApiKey('sk_test_ARGS9E1S9Ki5xf2kirmbZksd');

     // Token is created using Checkout or Elements!
     // Get the payment token ID submitted by the form:
     $token = $_POST['stripeToken'];
    $customer = $_POST['customer'];
     $charge = \Stripe\Charge::create([
         'amount' => 999,
         'currency' => 'usd',
         'description' => 'Example charge',
         'source' => $token,
     ]);
     //dd( $charge);
     return back()->with('payment_success','Payment is done');
}
}
