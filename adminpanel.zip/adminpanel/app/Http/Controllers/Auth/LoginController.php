<?php
namespace App\Http\Controllers\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Cookie;
class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
   // protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
   // public function __construct()
    //{
      //  $this->middleware('guest')->except('logout');
    //}
	public function log_in(Request $request)
    {
       $user_data=array(
		'email'  => $request->get('email'),
		'password'  => $request->get('password'),
 	   );
	 // $remember = $request->has('remember') ? true : false;
	  // $remember = $request->remember;
		//Cookie::queue('username',$user_data['email'],360);
		//Cookie::queue('password',$user_data['password'],360);
		$remember_me = $request->input('remember');

	   if(Auth::attempt($user_data) && $remember_me)
	   {
			Cookie::queue('username',$user_data['email'],360);
		Cookie::queue('password',$user_data['password'],360);
			 return redirect('dashboard');
	   }
	    elseif(Auth::attempt($user_data))
	   {
			 return redirect('dashboard');
	   }
	   else{
			//return redirect('signin');
			return back()->with('error','Wrong Username or Password');
	   }
    }
	public function log_out()
	{
		Cookie::queue(Cookie::forget('username'));
		Cookie::queue(Cookie::forget('password'));
		Auth::logout();
		return redirect('signin');

	}

}
